using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Railway.Pages
{
    public class station_informationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
