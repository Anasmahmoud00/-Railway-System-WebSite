using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Railway.Pages
{
    public class ManegerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
