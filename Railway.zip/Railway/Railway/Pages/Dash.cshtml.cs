using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Railway.Pages
{
    public class DashModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
