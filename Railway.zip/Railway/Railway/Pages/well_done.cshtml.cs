using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Railway.Pages
{
    public class well_doneModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
